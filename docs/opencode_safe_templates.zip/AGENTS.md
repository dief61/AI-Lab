# AGENTS.md - System-Anweisungen für OpenCode.ai

## 1. System- & Architektur-Kontext
- **Betriebssystem:** Ubuntu unter WSL2 (Windows Subsystem for Linux)
- **Editor / IDE:** VS Code (Remote WSL Extension)
- **Programmiersprache:** Python 3.11+
- **Paket- & Projektmanager:** `uv` (Astral)
- **Datenbank:** PostgreSQL 16 (in Docker Container ausgeführt, ggf. mit `pgvector`)
- **Versionierung:** Git
- **Vorgehensmodell:** SAFe-Anlehnung (Inkremente, Sprints, Features, User Stories)

---

## 2. Grundregeln für den KI-Agenten (OpenCode)
1. **Paketverwaltung mit uv:**
   - Installiere **niemals** Pakete mit `pip install` direkt.
   - Nutze stets `uv add <paketname>` für Abhängigkeiten.
   - Entwicklungsabhängigkeiten mit `uv add --dev <paketname>` hinzufügen.

2. **Test-Driven Development (TDD):**
   - Vor jeder Feature-Implementierung erst den passenden Test unter `tests/` mit `pytest` anlegen.
   - Erst wenn der Test existiert (und fehlschlägt), wird der Anwendungscode geschrieben.
   - Verifiziere Änderungen mit: `uv run pytest`.

3. **Datenbank & Docker:**
   - Verbindungen zu PostgreSQL erfolgen ausschließlich über Umgebungsvariablen (`.env`).
   - Standard-Host für lokale Entwicklung: `localhost:5432` oder Docker-Service-Name.
   - Führe DB-Abfragen asynchronous durch (z. B. via `asyncpg` oder `SQLAlchemy async`).

4. **SAFe Requirements Verarbeitung:**
   - Anforderungen befinden sich im Ordner `docs/requirements/stories/`.
   - Lies beim Bearbeiten einer Story die Akzeptanzkriterien exakt aus.
   - Aktualisiere nach Abschluss der Arbeiten den Status im Frontmatter der Story-Datei.

5. **Commit-Standards:**
   - Verwende Conventional Commits gekoppelt mit der Story-ID:
     Beispiel: `feat(db): #STORY-101 PostgreSQL Verbindungs-Pool integrieren`
