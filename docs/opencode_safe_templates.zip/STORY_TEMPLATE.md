---
id: STORY-101
title: "Titel der User Story"
type: Story # Epic | Feature | Story | Task
status: Draft # Draft | In Progress | Ready for Review | Done
assignee: OpenCode / Developer
sprint: Sprint-1.1
increment: PI-2026.1
---

# User Story: [Titel hier eintragen]

## 1. Beschreibung (SAFe Format)
**Als** [Rolle / Systemkomponente]
**möchte ich** [Funktionalität / Verhalten],
**damit** [Geschäftswert / Nutzen].

---

## 2. Kontext & Architektur-Bezug
- **Betroffene Komponenten:** (z. B. `db/connection.py`, `services/user_service.py`)
- **Datenbank-Änderungen:** (Ja / Nein - falls ja, Tabellen/Schema angeben)
- **Neue Abhängigkeiten:** (falls z. B. `uv add asyncpg` benötigt wird)

---

## 3. Akzeptanzkriterien (Maschinenlesbar für OpenCode TDD)

- [ ] **AK-1:** [Beschreibung des ersten Kriteriums]
  - *Test-Fall:* `tests/test_feature_x.py::test_kriterium_1`
  - *Erwartetes Verhalten:* [Konkretes Ergebnis / Rückgabewert]

- [ ] **AK-2:** [Beschreibung des zweiten Kriteriums]
  - *Test-Fall:* `tests/test_feature_x.py::test_kriterium_2`
  - *Erwartetes Verhalten:* [Konkretes Ergebnis]

---

## 4. Anweisung an OpenCode
1. Erstelle die pytest-Datei gemäß Akzeptanzkriterien AK-1 und AK-2.
2. Führe `uv run pytest` aus (Test muss fehlschlagen).
3. Implementiere den Code in den betroffenen Komponenten.
4. Führe erneut `uv run pytest` aus, bis alle Tests grün sind.
5. Aktualisiere den Status im Frontmatter auf `Done`.
